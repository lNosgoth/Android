package com.example.juegodados;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView tvpuntaje1,tvpuntaje2,tvganador;
    EditText etnum1,etnum2;
    int dado1,dado2,dado3,dado4,suma1,suma2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvpuntaje1=(TextView) findViewById(R.id.tvpuntaje1);
        tvpuntaje2=(TextView) findViewById(R.id.tvpuntaje2);
        tvganador=(TextView) findViewById(R.id.tvganador);

        etnum1=(EditText) findViewById(R.id.etnum1);
        etnum2=(EditText) findViewById(R.id.etnum2);

        SharedPreferences prefe1=getSharedPreferences("datos1", Context.MODE_PRIVATE);
        String x=String.valueOf(prefe1.getInt("puntos1",0));
        tvpuntaje1.setText(x);

        SharedPreferences prefe2=getSharedPreferences("datos2",Context.MODE_PRIVATE);
        String y=String.valueOf(prefe2.getInt("puntos2",0));
        tvpuntaje2.setText(y);

    }
    public void tirardados1 (View view)
    {
        int num=Integer.parseInt(etnum1.getText().toString());
        dado1=1+(int) (Math.random()*6);
        dado2=1+(int) (Math.random()*6);
        suma1=dado1+dado2;
        if (num==suma1 || dado1==1 || dado2==1)
        {
            int punto=Integer.parseInt(tvpuntaje1.getText().toString());
            punto+=1;
            tvpuntaje1.setText(String.valueOf(punto));;
            etnum1.setText("");
            Toast mensaje=Toast.makeText(this,"Felicidades, has ganado 1 punto",Toast.LENGTH_LONG);
            mensaje.show();

            SharedPreferences prefe=getSharedPreferences("datos1",Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=prefe.edit();
            editor.putInt("puntos1",punto);
            editor.commit();
        }else {
            Toast mensaje=Toast.makeText(this,"Fallaste, sigue intentandolo",Toast.LENGTH_LONG);
            etnum1.setText("");;
            mensaje.show();
        }
        Ganador(null);
    }
    public void tirardados2(View view) {
        int num2 = Integer.parseInt(etnum2.getText().toString());
        dado3 = 1 + (int) (Math.random() * 6);
        dado4 = 1 + (int) (Math.random() * 6);
        suma2 = dado3 + dado4;
        if (num2 == suma2 || dado3 == 1 || dado4 == 1)
        {
            int punto2=Integer.parseInt(tvpuntaje2.getText().toString());
            punto2+=1;
            tvpuntaje2.setText(String.valueOf(punto2));
            etnum2.setText("");
            Toast mensaje=Toast.makeText(this,"Felicidades, has ganado 1 punto",Toast.LENGTH_LONG);
            mensaje.show();

            SharedPreferences prefe=getSharedPreferences("datos2",Context.MODE_PRIVATE);
            SharedPreferences.Editor editor= prefe.edit();
            editor.putInt("puntos2",punto2);
            editor.commit();
        }else {
            Toast mensaje=Toast.makeText(this,"Fallaste, sigue Intendado",Toast.LENGTH_LONG);
            etnum2.setText("");
            mensaje.show();
        }
        Ganador(null);
    }

    private void Ganador(View view)
    {
        int punto1=Integer.parseInt(tvpuntaje1.getText().toString());
        int punto2=Integer.parseInt(tvpuntaje2.getText().toString());
        if (punto1>punto2)
        {
            tvganador.setText("El jugador 1 ha ganado con un total de: "+punto1+" puntos");
        }else if (punto2>punto1)
        {
            tvganador.setText("El jugador 2 ha ganado con un total de: "+punto2+" puntos");
        }else
        {
            tvganador.setText("");
        }
    }
    private void salir (View view)
    {
        finishAffinity();
    }
}