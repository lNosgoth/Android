package com.example.venta;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private RadioButton rbcompact,rbsony,rbdell;
    private CheckBox cbimpresora, cbescritorio,cbescaner;
    private TextView tvtotal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rbcompact=(RadioButton) findViewById(R.id.rbcompact);
        rbsony=(RadioButton) findViewById(R.id.rbsony);
        rbdell=(RadioButton) findViewById(R.id.rbdell);

        cbimpresora=(CheckBox) findViewById(R.id.cbimpresora);
        cbescritorio=(CheckBox) findViewById(R.id.cbescritorio);
        cbescaner=(CheckBox) findViewById(R.id.cbescaner);

        tvtotal=(TextView) findViewById(R.id.tvtotal);
    }

    public void calcularcompra(View view)
    {
        int compact=1000000;
        int sony=1500000;
        int dell=2000000;
        int impresora=150000;
        int escritorio=200000;
        int escaner=250000;
        int total=0;

        if (rbcompact.isChecked()==true || rbsony.isChecked()==true || rbdell.isChecked()==true)
        {
            if (cbimpresora.isChecked()==true || cbescritorio.isChecked()==true || cbescaner.isChecked()==true){

            }
        }
    }
}