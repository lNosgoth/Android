package com.example.vectordeelementos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edtv, edtv2;
    TextView tvml1, tvml2, tv1;

    int auxiliar,ordenar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvml1=(TextView) findViewById(R.id.tvml1);
        tvml2=(TextView) findViewById(R.id.tvml2);
        tv1=(TextView) findViewById(R.id.tv1);

        edtv=(EditText) findViewById(R.id.edtv);
        edtv2=(EditText) findViewById(R.id.edtv2);
    }

    public void cargarvector (View view){

        String valor="";
        int tamv=Integer.parseInt(edtv.getText().toString());
        int[]  vector=new int[tamv];

        for (int i=0;i< vector.length; i++){

            vector[i]=(int)(Math.random()*10)+1;
        }

        for (int i=0;i< vector.length;i++){

            String dato=String.valueOf(vector[i]+",");
            valor=valor+dato;

            tvml1.setText(valor);
        }

        ordenar=tamv-1;

        for (int i=0;i<ordenar;i++){

            for (int j=0;j<ordenar;j++){

                if (vector[j]>vector[j+1]){

                    auxiliar=vector[j];
                    vector[j]=vector[j+1];
                    vector[j+1]=auxiliar;
                }
            }
        }

        valor="";

        for (int i=0;i<vector.length;i++){

            String dato=String.valueOf(vector[i])+", ";
            valor=valor+dato;
            tvml2.setText(valor);

        }
    }

    public void busqueda (View view){



        int busqueda=Integer.parseInt(edtv2.getText().toString());
        for (int i=0;i<vector.length;i++){

            if (busqueda==vector[i]){

                tv1.setText(vector[i]+"Posicion" + i);
            }
            else{
                tv1.setText("No  se encontro el valor solicitado");
            }
        }

    }
}